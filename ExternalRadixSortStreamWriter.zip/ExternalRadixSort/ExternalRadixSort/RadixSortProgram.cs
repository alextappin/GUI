﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ExternalRadixSort
{
    class RadixSortProgram
    {
        static int NUMBER_OF_INTEGERS_TO_CREATE = 1000;
        static string testDatFile = "test.dat";
        static string bucket0DatFile = "bucket0.dat";
        static string bucket1DatFile = "bucket1.dat";
        static void Main(string[] args)
        {
            //Runs the sort and the checks
            RunSortAndCheck();
        }

        static void WriteToFile(string textToWrite, StreamWriter fileToWriteTo)
        {
            fileToWriteTo.WriteLine(textToWrite);
        }

        static void GenerateAndWriteRandomNumbers(string fileToWriteTo)
        {
            StreamWriter randomIntegersWriter = new StreamWriter(fileToWriteTo);
            Random rnd = new Random();
            //write random numbers to the file
            for (int i = 0; i < NUMBER_OF_INTEGERS_TO_CREATE; i++)
                WriteToFile(rnd.Next().ToString(), randomIntegersWriter);
            //stop writing
            randomIntegersWriter.Close();
        }

        static bool CheckGoodSort()
        {
            StreamReader randomIntegersReader = new StreamReader(testDatFile);
            //need to initialize it with the first number
            uint firstNum = Convert.ToUInt32(randomIntegersReader.ReadLine());
            uint secondNum;
            bool incorrect = false;

            while (randomIntegersReader.Peek() >= 0 && !incorrect)
            {
                secondNum = Convert.ToUInt32(randomIntegersReader.ReadLine());

                if (firstNum > secondNum)
                {
                    incorrect = true;
                    Console.WriteLine("Out of Order");
                    return false;
                }
                firstNum = Convert.ToUInt32(randomIntegersReader.ReadLine());
            }
            randomIntegersReader.Close();
            return true;
        }

        static void RunSortAndCheck()
        {
            //runs until the count is met or CheckSort returns false
            int Count = 0;
            //do while because the checkGoodSort will return false if it was never sorted.
            do
            {
                GenerateAndWriteRandomNumbers(testDatFile);
                RadixSort();
                Count++;
            } while (Count < 10000 && CheckGoodSort());
        }

        static void RadixSort()
        {
            Stopwatch stopwatch = new Stopwatch();
            uint numberToMaskWith = 1;
            uint currentNumberRead;
            uint numberToStoreInBucket;
            int count = 0;
            stopwatch.Start();
            while (count < 30)
            {
                //basically 2^count and then mask
                //moving the bit up 1 each time -> 0b0001 = 1 = 2^0, 0b0010 = 2 = 2^1, 0b0100 = 4 = 2^2 etc...
                numberToMaskWith = Convert.ToUInt32(Math.Pow(2, count));
                //open files to write and read to
                StreamReader randomIntegersReader = new StreamReader(testDatFile);
                StreamWriter bucket0Writer = new StreamWriter(bucket0DatFile);
                StreamWriter bucket1Writer = new StreamWriter(bucket1DatFile);

                //make sure to read all the numbers line by line
                while (randomIntegersReader.Peek() >= 0)
                {
                    //get the number to store in the bucket
                    currentNumberRead = Convert.ToUInt32(randomIntegersReader.ReadLine());
                    numberToStoreInBucket = currentNumberRead;
                    //mask the number with the number to mask
                    currentNumberRead = currentNumberRead & numberToMaskWith;
                    //if the bit is a 0, put in bucket0, if it is a 1, put in bucket1
                    if (currentNumberRead == 0)
                        WriteToFile(numberToStoreInBucket.ToString(), bucket0Writer);
                    else
                        WriteToFile(numberToStoreInBucket.ToString(), bucket1Writer);
                }
                //Close files
                bucket0Writer.Close();
                bucket1Writer.Close();
                randomIntegersReader.Close();
                //Open files
                StreamReader firstBucketReader = new StreamReader(bucket0DatFile);
                StreamReader secondBucketReader = new StreamReader(bucket1DatFile);
                StreamWriter orderingNumbersProgress = new StreamWriter(testDatFile);
                //Write 0's and 1's to the testDatFile
                while (firstBucketReader.Peek() >= 0)
                    WriteToFile(firstBucketReader.ReadLine().ToString(), orderingNumbersProgress);
                while (secondBucketReader.Peek() >= 0)
                    WriteToFile(secondBucketReader.ReadLine().ToString(), orderingNumbersProgress);
                //close them after finishing writing and reading
                firstBucketReader.Close();
                secondBucketReader.Close();
                orderingNumbersProgress.Close();
                //increment count for while loop.
                count++;
            }
            stopwatch.Stop();
            TimeSpan timeElapsed =  stopwatch.Elapsed;
            Console.WriteLine(timeElapsed.Milliseconds);
        }
    }
}
